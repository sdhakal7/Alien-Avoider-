#ifndef ANOTHERROCKET_H
#define ANOTHERROCKET_H

#define ANOTHERROCKET_WIDTH  (32)
#define ANOTHERROCKET_HEIGHT (32)
#define anotherRocketLen (2048)

extern const unsigned short anotherRocketMap[1024];

#endif

// spaceMusic sound made by wav2c

extern const unsigned int spaceMusic_sampleRate;
extern const unsigned int spaceMusic_length;
extern const signed char spaceMusic_data[];

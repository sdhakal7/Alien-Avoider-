#ifndef PLANETS_H
#define PLANETS_H

#define PLANETS_WIDTH  (32)
#define PLANETS_HEIGHT (32)
#define planetsLen (2048)

extern const unsigned short planetsMap[1024];

#endif

#ifndef ROCKETSHIPS_H
#define ROCKETSHIPS_H

#define ROCKETSHIPS_WIDTH  (32)
#define ROCKETSHIPS_HEIGHT (32)
#define rocketshipsLen (2048)

extern const unsigned short rocketshipsMap[1024];

#endif

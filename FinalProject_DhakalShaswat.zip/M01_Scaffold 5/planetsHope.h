#ifndef PLANETSHOPE_H
#define PLANETSHOPE_H

#define PLANETSHOPE_WIDTH  (32)
#define PLANETSHOPE_HEIGHT (32)
#define planetsHopeLen (2048)

extern const unsigned short planetsHopeMap[1024];

#endif

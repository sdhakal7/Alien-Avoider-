﻿# **Final Project**

## What is done

So far, I have completed the state machine, I implemented the character being able to go up and down, enemies coming towards the character, the enemy shooting bullets, a power up that allows the player to shoot bullets at all the enemies (but not the enemies perviously shot bullets) , an UFO enemy that captures a player if the player collides with it from below, a cheat that gives the player invisibility to all enemies and bullets for a limited period of time (player can acquire this by colliding on top of the UFO), a black hole enemy that appears less frequently than other enemy types but only has to travel half the distance to suck in the player, and the lose conditions. I have also implemented palette modification. This allows the user to fully play my game.  

I have implemented title modification. I have added in game instructions. I have over 4 unique sprites. All of my art is original. The blackhole is a plain oval because it has to be. I have a looping sound and a non-looping sound. I have 2 backgrounds moving at different speeds. 


## What I am missing

 I do not have any animated sprites.


## Bugs

None that I am aware of
## How to play (in current state)

In start state:
- Press left button to go to instructions
- Press right button to go to game

In instructions state: 
- Press A button to go to start
- Use the up and down buttons to scroll up and down to see all of the instructions

In game state:
- Hold the up button to travel up
- Let go of the up button to fall (or stay where you are if you are at the bottom)
- If you get hit by the alien enemy or the alien enemy's bullets you lose
- Press right shoulder button to go to pause
- if you collide with the bottom or center of the UFO enemy, you lose
- If you collide with the top of the UFO enemy, you get the cheat which allows you to be invisible to all enemies for a limited period of time 
- If you get sucked in the blackhole enemy you lose (note, this means you do not have to collide with it. If you come close enough to it, it will pull you in)
- If you collide with a power-up box, you can press A to activate the power-up
- Once you have activated the power-up, you can fire bullets that kill all three types of enemies (this will not kill the previously fired bullets of the alien enemy) for a limited period of time.
- Press right shoulder button to go to pause

In pause state:
- Press left button to go to start
- Press right shoulder button to go to game.

In lose state:
- Press B button to go to start.



<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="titlemap" tilewidth="8" tileheight="8" tilecount="6" columns="6">
 <image source="titlemap.bmp" width="48" height="8"/>
</tileset>

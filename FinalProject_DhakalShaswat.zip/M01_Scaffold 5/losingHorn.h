// losingHorn sound made by wav2c

extern const unsigned int losingHorn_sampleRate;
extern const unsigned int losingHorn_length;
extern const signed char losingHorn_data[];

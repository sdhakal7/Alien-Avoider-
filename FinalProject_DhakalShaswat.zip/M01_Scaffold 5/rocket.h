#ifndef ROCKET_H
#define ROCKET_H

#define ROCKET_WIDTH  (32)
#define ROCKET_HEIGHT (32)
#define rocketLen (2048)

extern const unsigned short rocketMap[1024];

#endif

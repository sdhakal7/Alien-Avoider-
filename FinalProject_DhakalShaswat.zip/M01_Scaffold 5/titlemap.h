
//{{BLOCK(titlemap)

//======================================================================
//
//	titlemap, 48x8@8, 
//	+ palette 256 entries, not compressed
//	+ 6 tiles not compressed
//	Total size: 512 + 384 = 896
//
//	Time-stamp: 2024-12-05, 01:15:09
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TITLEMAP_H
#define GRIT_TITLEMAP_H

#define titlemapTilesLen 384
extern const unsigned short titlemapTiles[192];

#define titlemapPalLen 512
extern const unsigned short titlemapPal[256];

#endif // GRIT_TITLEMAP_H

//}}BLOCK(titlemap)

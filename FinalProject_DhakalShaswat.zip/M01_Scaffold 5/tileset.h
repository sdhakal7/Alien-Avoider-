
//{{BLOCK(tileset)

//======================================================================
//
//	tileset, 56x16@8, 
//	+ palette 256 entries, not compressed
//	+ 6 tiles (t|f|p reduced) not compressed
//	+ regular map (flat), not compressed, 7x2 
//	Total size: 512 + 384 + 28 = 924
//
//	Time-stamp: 2024-11-30, 21:53:57
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TILESET_H
#define GRIT_TILESET_H

#define tilesetTilesLen 384
extern const unsigned short tilesetTiles[192];

#define tilesetMapLen 28
extern const unsigned short tilesetMap[14];

#define tilesetPalLen 512
extern const unsigned short tilesetPal[256];

#endif // GRIT_TILESET_H

//}}BLOCK(tileset)

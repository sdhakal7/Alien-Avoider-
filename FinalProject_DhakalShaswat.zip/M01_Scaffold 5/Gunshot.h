// Gunshot sound made by wav2c

extern const unsigned int Gunshot_sampleRate;
extern const unsigned int Gunshot_length;
extern const signed char Gunshot_data[];

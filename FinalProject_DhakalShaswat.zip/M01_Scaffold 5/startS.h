
//{{BLOCK(startS)

//======================================================================
//
//	startS, 256x256@8, 
//	+ palette 256 entries, not compressed
//	+ 3 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 192 + 2048 = 2752
//
//	Time-stamp: 2024-11-05, 23:32:33
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTS_H
#define GRIT_STARTS_H

#define startSTilesLen 192
extern const unsigned short startSTiles[96];

#define startSMapLen 2048
extern const unsigned short startSMap[1024];

#define startSPalLen 512
extern const unsigned short startSPal[256];

#endif // GRIT_STARTS_H

//}}BLOCK(startS)

// spaceCadetClean sound made by wav2c

extern const unsigned int spaceCadetClean_sampleRate;
extern const unsigned int spaceCadetClean_length;
extern const signed char spaceCadetClean_data[];

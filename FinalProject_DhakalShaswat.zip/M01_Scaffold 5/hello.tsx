<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="hello" tilewidth="8" tileheight="8" tilecount="14" columns="7">
 <image source="../Lab07/Tiles/tileset.bmp" width="56" height="16"/>
</tileset>
